g03 /home/allouche/MySoftwares/CChemI/CChemI-01062018/cchemi/tests/testRDFragments/CX4CuGeoms_1.com
g03 /home/allouche/MySoftwares/CChemI/CChemI-01062018/cchemi/tests/testRDFragments/CX4CuGeoms_2.com
g03 /home/allouche/MySoftwares/CChemI/CChemI-01062018/cchemi/tests/testRDFragments/CX4CuGeoms_3.com
g03 /home/allouche/MySoftwares/CChemI/CChemI-01062018/cchemi/tests/testRDFragments/CX4CuGeoms_4.com
g03 /home/allouche/MySoftwares/CChemI/CChemI-01062018/cchemi/tests/testRDFragments/CX4CuGeoms_5.com
g03 /home/allouche/MySoftwares/CChemI/CChemI-01062018/cchemi/tests/testRDFragments/CX4CuGeoms_6.com
g03 /home/allouche/MySoftwares/CChemI/CChemI-01062018/cchemi/tests/testRDFragments/CX4CuGeoms_7.com
g03 /home/allouche/MySoftwares/CChemI/CChemI-01062018/cchemi/tests/testRDFragments/CX4CuGeoms_8.com
