g03 /home/allouche/MySoftwares/CChemI/CChemI-05042019/cchemi/tests/HDNNP/h2o_2Geoms_1.com
g03 /home/allouche/MySoftwares/CChemI/CChemI-05042019/cchemi/tests/HDNNP/h2o_2Geoms_2.com
