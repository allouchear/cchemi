orca /home/allouche/MySoftwares/CChemI/CChemI-05042019/cchemi/tests/HDNNP/h2o_2GeomsORCA_1.inp > /home/allouche/MySoftwares/CChemI/CChemI-05042019/cchemi/tests/HDNNP/h2o_2GeomsORCA_1.out
orca /home/allouche/MySoftwares/CChemI/CChemI-05042019/cchemi/tests/HDNNP/h2o_2GeomsORCA_2.inp > /home/allouche/MySoftwares/CChemI/CChemI-05042019/cchemi/tests/HDNNP/h2o_2GeomsORCA_2.out
