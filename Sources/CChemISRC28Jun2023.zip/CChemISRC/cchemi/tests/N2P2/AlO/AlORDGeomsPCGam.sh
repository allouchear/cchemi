mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp1
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp1
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_1.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_1.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_1.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp1
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp2
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp2
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_2.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_2.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_2.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp2
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp3
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp3
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_3.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_3.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_3.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp3
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp4
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp4
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_4.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_4.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_4.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp4
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp5
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp5
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_5.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_5.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_5.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp5
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp6
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp6
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_6.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_6.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_6.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp6
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp7
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp7
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_7.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_7.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_7.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp7
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp8
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp8
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_8.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_8.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_8.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp8
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp9
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp9
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_9.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_9.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_9.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp9
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp10
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp10
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_10.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_10.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_10.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp10
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp11
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp11
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_11.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_11.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_11.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp11
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp12
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp12
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_12.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_12.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_12.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp12
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp13
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp13
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_13.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_13.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_13.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp13
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp14
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp14
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_14.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_14.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_14.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp14
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp15
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp15
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_15.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_15.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_15.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp15
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp16
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp16
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_16.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_16.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_16.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp16
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp17
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp17
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_17.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_17.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_17.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp17
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp18
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp18
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_18.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_18.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_18.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp18
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp19
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp19
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_19.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_19.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_19.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp19
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp20
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp20
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_20.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_20.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_20.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp20
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp21
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp21
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_21.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_21.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_21.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp21
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp22
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp22
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_22.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_22.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_22.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp22
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp23
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp23
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_23.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_23.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_23.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp23
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp24
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp24
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_24.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_24.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_24.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp24
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp25
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp25
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_25.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_25.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_25.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp25
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp26
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp26
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_26.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_26.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_26.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp26
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp27
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp27
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_27.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_27.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_27.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp27
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp28
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp28
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_28.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_28.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_28.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp28
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp29
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp29
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_29.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_29.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_29.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp29
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp30
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp30
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_30.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_30.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_30.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp30
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp31
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp31
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_31.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_31.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_31.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp31
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp32
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp32
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_32.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_32.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_32.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp32
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp33
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp33
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_33.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_33.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_33.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp33
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp34
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp34
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_34.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_34.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_34.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp34
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp35
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp35
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_35.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_35.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_35.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp35
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp36
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp36
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_36.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_36.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_36.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp36
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp37
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp37
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_37.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_37.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_37.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp37
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp38
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp38
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_38.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_38.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_38.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp38
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp39
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp39
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_39.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_39.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_39.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp39
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp40
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp40
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_40.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_40.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_40.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp40
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp41
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp41
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_41.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_41.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_41.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp41
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp42
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp42
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_42.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_42.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_42.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp42
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp43
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp43
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_43.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_43.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_43.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp43
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp44
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp44
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_44.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_44.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_44.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp44
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp45
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp45
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_45.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_45.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_45.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp45
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp46
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp46
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_46.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_46.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_46.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp46
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp47
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp47
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_47.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_47.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_47.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp47
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp48
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp48
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_48.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_48.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_48.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp48
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp49
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp49
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_49.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_49.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_49.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp49
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp50
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp50
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_50.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_50.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_50.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp50
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp51
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp51
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_51.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_51.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_51.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp51
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp52
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp52
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_52.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_52.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_52.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp52
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp53
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp53
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_53.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_53.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_53.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp53
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp54
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp54
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_54.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_54.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_54.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp54
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp55
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp55
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_55.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_55.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_55.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp55
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp56
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp56
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_56.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_56.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_56.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp56
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp57
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp57
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_57.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_57.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_57.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp57
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp58
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp58
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_58.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_58.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_58.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp58
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp59
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp59
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_59.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_59.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_59.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp59
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp60
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp60
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_60.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_60.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_60.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp60
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp61
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp61
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_61.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_61.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_61.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp61
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp62
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp62
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_62.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_62.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_62.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp62
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp63
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp63
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_63.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_63.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_63.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp63
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp64
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp64
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_64.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_64.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_64.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp64
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp65
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp65
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_65.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_65.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_65.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp65
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp66
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp66
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_66.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_66.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_66.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp66
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp67
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp67
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_67.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_67.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_67.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp67
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp68
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp68
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_68.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_68.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_68.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp68
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp69
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp69
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_69.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_69.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_69.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp69
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp70
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp70
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_70.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_70.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_70.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp70
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp71
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp71
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_71.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_71.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_71.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp71
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp72
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp72
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_72.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_72.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_72.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp72
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp73
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp73
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_73.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_73.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_73.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp73
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp74
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp74
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_74.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_74.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_74.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp74
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp75
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp75
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_75.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_75.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_75.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp75
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp76
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp76
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_76.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_76.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_76.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp76
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp77
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp77
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_77.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_77.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_77.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp77
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp78
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp78
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_78.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_78.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_78.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp78
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp79
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp79
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_79.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_79.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_79.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp79
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp80
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp80
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_80.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_80.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_80.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp80
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp81
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp81
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_81.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_81.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_81.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp81
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp82
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp82
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_82.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_82.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_82.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp82
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp83
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp83
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_83.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_83.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_83.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp83
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp84
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp84
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_84.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_84.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_84.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp84
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp85
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp85
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_85.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_85.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_85.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp85
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp86
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp86
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_86.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_86.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_86.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp86
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp87
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp87
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_87.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_87.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_87.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp87
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp88
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp88
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_88.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_88.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_88.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp88
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp89
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp89
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_89.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_89.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_89.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp89
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp90
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp90
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_90.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_90.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_90.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp90
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp91
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp91
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_91.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_91.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_91.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp91
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp92
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp92
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_92.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_92.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_92.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp92
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp93
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp93
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_93.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_93.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_93.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp93
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp94
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp94
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_94.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_94.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_94.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp94
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp95
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp95
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_95.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_95.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_95.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp95
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp96
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp96
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_96.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_96.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_96.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp96
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp97
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp97
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_97.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_97.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_97.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp97
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp98
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp98
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_98.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_98.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_98.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp98
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp99
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp99
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_99.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_99.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_99.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp99
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp100
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp100
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_100.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_100.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_100.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp100
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp101
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp101
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_101.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_101.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_101.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp101
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp102
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp102
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_102.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_102.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_102.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp102
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp103
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp103
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_103.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_103.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_103.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp103
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp104
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp104
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_104.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_104.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_104.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp104
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp105
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp105
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_105.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_105.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_105.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp105
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp106
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp106
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_106.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_106.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_106.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp106
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp107
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp107
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_107.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_107.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_107.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp107
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp108
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp108
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_108.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_108.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_108.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp108
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp109
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp109
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_109.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_109.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_109.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp109
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp110
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp110
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_110.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_110.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_110.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp110
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp111
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp111
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_111.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_111.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_111.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp111
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp112
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp112
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_112.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_112.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_112.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp112
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp113
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp113
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_113.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_113.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_113.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp113
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp114
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp114
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_114.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_114.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_114.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp114
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp115
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp115
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_115.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_115.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_115.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp115
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp116
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp116
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_116.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_116.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_116.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp116
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp117
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp117
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_117.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_117.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_117.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp117
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp118
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp118
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_118.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_118.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_118.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp118
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp119
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp119
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_119.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_119.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_119.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp119
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp120
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp120
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_120.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_120.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_120.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp120
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp121
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp121
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_121.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_121.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_121.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp121
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp122
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp122
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_122.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_122.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_122.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp122
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp123
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp123
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_123.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_123.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_123.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp123
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp124
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp124
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_124.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_124.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_124.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp124
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp125
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp125
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_125.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_125.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_125.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp125
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp126
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp126
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_126.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_126.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_126.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp126
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp127
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp127
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_127.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_127.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_127.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp127
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp128
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp128
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_128.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_128.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_128.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp128
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp129
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp129
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_129.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_129.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_129.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp129
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp130
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp130
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_130.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_130.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_130.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp130
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp131
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp131
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_131.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_131.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_131.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp131
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp132
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp132
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_132.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_132.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_132.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp132
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp133
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp133
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_133.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_133.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_133.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp133
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp134
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp134
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_134.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_134.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_134.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp134
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp135
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp135
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_135.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_135.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_135.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp135
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp136
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp136
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_136.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_136.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_136.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp136
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp137
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp137
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_137.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_137.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_137.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp137
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp138
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp138
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_138.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_138.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_138.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp138
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp139
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp139
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_139.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_139.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_139.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp139
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp140
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp140
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_140.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_140.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_140.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp140
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp141
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp141
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_141.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_141.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_141.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp141
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp142
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp142
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_142.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_142.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_142.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp142
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp143
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp143
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_143.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_143.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_143.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp143
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp144
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp144
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_144.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_144.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_144.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp144
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp145
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp145
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_145.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_145.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_145.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp145
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp146
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp146
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_146.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_146.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_146.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp146
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp147
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp147
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_147.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_147.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_147.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp147
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp148
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp148
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_148.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_148.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_148.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp148
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp149
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp149
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_149.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_149.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_149.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp149
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp150
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp150
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_150.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_150.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_150.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp150
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp151
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp151
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_151.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_151.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_151.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp151
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp152
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp152
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_152.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_152.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_152.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp152
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp153
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp153
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_153.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_153.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_153.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp153
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp154
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp154
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_154.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_154.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_154.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp154
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp155
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp155
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_155.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_155.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_155.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp155
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp156
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp156
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_156.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_156.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_156.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp156
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp157
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp157
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_157.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_157.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_157.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp157
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp158
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp158
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_158.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_158.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_158.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp158
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp159
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp159
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_159.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_159.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_159.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp159
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp160
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp160
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_160.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_160.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_160.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp160
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp161
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp161
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_161.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_161.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_161.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp161
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp162
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp162
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_162.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_162.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_162.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp162
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp163
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp163
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_163.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_163.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_163.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp163
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp164
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp164
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_164.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_164.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_164.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp164
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp165
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp165
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_165.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_165.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_165.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp165
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp166
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp166
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_166.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_166.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_166.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp166
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp167
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp167
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_167.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_167.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_167.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp167
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp168
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp168
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_168.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_168.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_168.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp168
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp169
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp169
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_169.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_169.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_169.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp169
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp170
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp170
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_170.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_170.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_170.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp170
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp171
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp171
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_171.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_171.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_171.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp171
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp172
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp172
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_172.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_172.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_172.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp172
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp173
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp173
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_173.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_173.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_173.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp173
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp174
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp174
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_174.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_174.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_174.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp174
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp175
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp175
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_175.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_175.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_175.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp175
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp176
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp176
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_176.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_176.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_176.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp176
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp177
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp177
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_177.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_177.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_177.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp177
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp178
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp178
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_178.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_178.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_178.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp178
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp179
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp179
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_179.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_179.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_179.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp179
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp180
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp180
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_180.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_180.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_180.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp180
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp181
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp181
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_181.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_181.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_181.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp181
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp182
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp182
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_182.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_182.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_182.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp182
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp183
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp183
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_183.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_183.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_183.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp183
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp184
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp184
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_184.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_184.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_184.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp184
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp185
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp185
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_185.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_185.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_185.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp185
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp186
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp186
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_186.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_186.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_186.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp186
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp187
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp187
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_187.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_187.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_187.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp187
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp188
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp188
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_188.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_188.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_188.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp188
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp189
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp189
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_189.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_189.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_189.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp189
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp190
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp190
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_190.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_190.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_190.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp190
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp191
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp191
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_191.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_191.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_191.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp191
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp192
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp192
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_192.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_192.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_192.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp192
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp193
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp193
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_193.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_193.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_193.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp193
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp194
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp194
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_194.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_194.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_194.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp194
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp195
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp195
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_195.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_195.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_195.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp195
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp196
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp196
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_196.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_196.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_196.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp196
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp197
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp197
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_197.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_197.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_197.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp197
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp198
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp198
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_198.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_198.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_198.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp198
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp199
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp199
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_199.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_199.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_199.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp199
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp200
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp200
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_200.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_200.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_200.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp200
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp201
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp201
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_201.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_201.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_201.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp201
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp202
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp202
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_202.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_202.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_202.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp202
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp203
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp203
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_203.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_203.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_203.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp203
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp204
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp204
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_204.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_204.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_204.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp204
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp205
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp205
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_205.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_205.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_205.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp205
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp206
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp206
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_206.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_206.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_206.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp206
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp207
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp207
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_207.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_207.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_207.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp207
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp208
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp208
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_208.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_208.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_208.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp208
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp209
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp209
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_209.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_209.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_209.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp209
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp210
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp210
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_210.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_210.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_210.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp210
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp211
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp211
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_211.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_211.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_211.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp211
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp212
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp212
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_212.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_212.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_212.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp212
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp213
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp213
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_213.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_213.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_213.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp213
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp214
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp214
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_214.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_214.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_214.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp214
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp215
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp215
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_215.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_215.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_215.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp215
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp216
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp216
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_216.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_216.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_216.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp216
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp217
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp217
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_217.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_217.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_217.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp217
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp218
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp218
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_218.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_218.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_218.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp218
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp219
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp219
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_219.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_219.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_219.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp219
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp220
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp220
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_220.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_220.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_220.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp220
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp221
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp221
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_221.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_221.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_221.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp221
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp222
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp222
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_222.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_222.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_222.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp222
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp223
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp223
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_223.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_223.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_223.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp223
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp224
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp224
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_224.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_224.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_224.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp224
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp225
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp225
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_225.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_225.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_225.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp225
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp226
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp226
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_226.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_226.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_226.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp226
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp227
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp227
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_227.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_227.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_227.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp227
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp228
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp228
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_228.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_228.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_228.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp228
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp229
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp229
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_229.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_229.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_229.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp229
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp230
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp230
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_230.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_230.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_230.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp230
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp231
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp231
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_231.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_231.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_231.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp231
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp232
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp232
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_232.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_232.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_232.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp232
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp233
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp233
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_233.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_233.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_233.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp233
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp234
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp234
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_234.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_234.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_234.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp234
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp235
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp235
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_235.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_235.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_235.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp235
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp236
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp236
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_236.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_236.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_236.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp236
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp237
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp237
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_237.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_237.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_237.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp237
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp238
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp238
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_238.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_238.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_238.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp238
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp239
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp239
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_239.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_239.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_239.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp239
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp240
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp240
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_240.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_240.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_240.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp240
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp241
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp241
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_241.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_241.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_241.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp241
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp242
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp242
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_242.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_242.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_242.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp242
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp243
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp243
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_243.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_243.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_243.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp243
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp244
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp244
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_244.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_244.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_244.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp244
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp245
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp245
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_245.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_245.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_245.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp245
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp246
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp246
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_246.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_246.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_246.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp246
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp247
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp247
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_247.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_247.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_247.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp247
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp248
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp248
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_248.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_248.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_248.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp248
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp249
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp249
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_249.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_249.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_249.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp249
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp250
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp250
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_250.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_250.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_250.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp250
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp251
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp251
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_251.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_251.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_251.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp251
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp252
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp252
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_252.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_252.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_252.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp252
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp253
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp253
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_253.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_253.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_253.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp253
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp254
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp254
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_254.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_254.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_254.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp254
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp255
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp255
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_255.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_255.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_255.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp255
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp256
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp256
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_256.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_256.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_256.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp256
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp257
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp257
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_257.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_257.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_257.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp257
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp258
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp258
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_258.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_258.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_258.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp258
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp259
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp259
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_259.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_259.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_259.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp259
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp260
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp260
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_260.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_260.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_260.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp260
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp261
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp261
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_261.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_261.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_261.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp261
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp262
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp262
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_262.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_262.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_262.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp262
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp263
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp263
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_263.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_263.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_263.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp263
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp264
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp264
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_264.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_264.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_264.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp264
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp265
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp265
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_265.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_265.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_265.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp265
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp266
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp266
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_266.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_266.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_266.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp266
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp267
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp267
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_267.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_267.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_267.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp267
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp268
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp268
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_268.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_268.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_268.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp268
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp269
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp269
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_269.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_269.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_269.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp269
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp270
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp270
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_270.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_270.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_270.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp270
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp271
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp271
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_271.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_271.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_271.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp271
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp272
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp272
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_272.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_272.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_272.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp272
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp273
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp273
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_273.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_273.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_273.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp273
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp274
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp274
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_274.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_274.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_274.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp274
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp275
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp275
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_275.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_275.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_275.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp275
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp276
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp276
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_276.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_276.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_276.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp276
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp277
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp277
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_277.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_277.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_277.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp277
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp278
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp278
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_278.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_278.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_278.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp278
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp279
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp279
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_279.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_279.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_279.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp279
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp280
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp280
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_280.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_280.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_280.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp280
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp281
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp281
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_281.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_281.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_281.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp281
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp282
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp282
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_282.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_282.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_282.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp282
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp283
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp283
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_283.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_283.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_283.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp283
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp284
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp284
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_284.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_284.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_284.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp284
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp285
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp285
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_285.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_285.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_285.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp285
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp286
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp286
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_286.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_286.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_286.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp286
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp287
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp287
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_287.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_287.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_287.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp287
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp288
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp288
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_288.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_288.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_288.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp288
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp289
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp289
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_289.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_289.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_289.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp289
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp290
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp290
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_290.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_290.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_290.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp290
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp291
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp291
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_291.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_291.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_291.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp291
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp292
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp292
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_292.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_292.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_292.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp292
mkdir /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp293
cd /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp293
cp /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_293.inp input
firefly -p -o /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_293.log
cd ..
mv PUNCH  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomsFF_293.pun
/bin/rm -r  /home/allouche/MySoftwares/CChemI/CChemI-29042019/cchemi/tests/HDNNP/AlO/AlORDGeomstmp293
