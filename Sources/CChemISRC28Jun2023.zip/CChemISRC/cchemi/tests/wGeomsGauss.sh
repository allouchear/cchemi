g09 /home/allouche/CChemI-040315/cchemi/tests/wGeoms_1.com
g09 /home/allouche/CChemI-040315/cchemi/tests/wGeoms_2.com
