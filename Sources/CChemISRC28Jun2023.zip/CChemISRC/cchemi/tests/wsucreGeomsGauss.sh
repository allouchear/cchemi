g09 /home/allouche/CChemI-040315/cchemi/tests/wsucreGeoms_1.com
g09 /home/allouche/CChemI-040315/cchemi/tests/wsucreGeoms_2.com
g09 /home/allouche/CChemI-040315/cchemi/tests/wsucreGeoms_3.com
g09 /home/allouche/CChemI-040315/cchemi/tests/wsucreGeoms_4.com
g09 /home/allouche/CChemI-040315/cchemi/tests/wsucreGeoms_5.com
