orca /home/allouche/CChemI/CChemI-100415/cchemi/tests/h2oGeomsORCA_1.inp > /home/allouche/CChemI/CChemI-100415/cchemi/tests/h2oGeomsORCA_1.out
