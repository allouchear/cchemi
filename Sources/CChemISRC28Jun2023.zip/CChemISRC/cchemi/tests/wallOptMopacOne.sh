mopac /home/allouche/CChemI-030315/cchemi/tests/wallOptOne.mop
