mopac /home/allouche/MySoftwares/MyMLSoftDerivatives/CChemI-05012020/cchemi/tests/testFreqOptOne.mop
