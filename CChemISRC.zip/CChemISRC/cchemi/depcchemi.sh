cd ..
source env.sh
cd -
make dep
