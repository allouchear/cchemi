time mpiexec -np 8 lascmd a.inp> a.log
