export LD_LIBRARY_PATH=/home/allouche/Softwares/ati-stream-sdk-v2.2-lnx32/lib/x86:.:$LD_LIBRARY_PATH
lascmdCLCPU $1
ldd lascmdCLCPU
