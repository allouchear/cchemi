#!/bin/bash
cd ..
source env.sh
cd -
make clean
