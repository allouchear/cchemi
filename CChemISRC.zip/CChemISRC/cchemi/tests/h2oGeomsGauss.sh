g03 /home/allouche/CChemI/CChemI-100415/cchemi/tests/h2oGeoms_1.com
