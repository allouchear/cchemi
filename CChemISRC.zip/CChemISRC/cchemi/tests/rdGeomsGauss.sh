g03 /home/allouche/MySoftwares/CChemI/CChemI-01012018/cchemi/tests/rdGeoms_1.com
g03 /home/allouche/MySoftwares/CChemI/CChemI-01012018/cchemi/tests/rdGeoms_2.com
g03 /home/allouche/MySoftwares/CChemI/CChemI-01012018/cchemi/tests/rdGeoms_3.com
g03 /home/allouche/MySoftwares/CChemI/CChemI-01012018/cchemi/tests/rdGeoms_4.com
g03 /home/allouche/MySoftwares/CChemI/CChemI-01012018/cchemi/tests/rdGeoms_5.com
