mopac /home/allouche/MySoftwares/CChemI/CChemI-05042019/cchemi/tests/HDNNP/h2o_2Geoms_1.mop
mopac /home/allouche/MySoftwares/CChemI/CChemI-05042019/cchemi/tests/HDNNP/h2o_2Geoms_2.mop
