mopac /home/allouche/MySoftwares/CChemI/CChemI-01062018/cchemi/tests/testRDFragments/RDFGeomsOne.mop
