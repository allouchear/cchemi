mopac /home/allouche/MySoftwares/CChemI/CChemI-01062018/cchemi/tests/testRDFragments/CX4CuGeomsOne.mop
