obopt -ff gaff /home/allouche/MySoftwares/CChemI/CChemI-19072019/cchemi/tests/RemoveSimilarConfo/3_NAcGeomsOne.hin > /home/allouche/MySoftwares/CChemI/CChemI-19072019/cchemi/tests/RemoveSimilarConfo/3_NAcGeomsOne.out
exit
