orca /home_nfs/ilm/allouche/tmp/CChemI-191215/cchemi/tests/testOpenBabel/mdMopacGeomsORCA_1.inp > /home_nfs/ilm/allouche/tmp/CChemI-191215/cchemi/tests/testOpenBabel/mdMopacGeomsORCA_1.out
orca /home_nfs/ilm/allouche/tmp/CChemI-191215/cchemi/tests/testOpenBabel/mdMopacGeomsORCA_2.inp > /home_nfs/ilm/allouche/tmp/CChemI-191215/cchemi/tests/testOpenBabel/mdMopacGeomsORCA_2.out
