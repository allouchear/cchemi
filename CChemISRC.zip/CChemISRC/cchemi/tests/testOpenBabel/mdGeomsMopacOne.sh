mopac /home_nfs/ilm/allouche/tmp/CChemI-191215/cchemi/tests/testOpenBabel/mdGeomsOne.mop
