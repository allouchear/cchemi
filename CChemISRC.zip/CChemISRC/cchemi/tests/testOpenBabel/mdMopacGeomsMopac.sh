mopac /home_nfs/ilm/allouche/tmp/CChemI-191215/cchemi/tests/testOpenBabel/mdMopacGeoms_1.mop
mopac /home_nfs/ilm/allouche/tmp/CChemI-191215/cchemi/tests/testOpenBabel/mdMopacGeoms_2.mop
