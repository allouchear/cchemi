mopac /home/allouche/CChemI/CChemI-101215/cchemi/tests/testGradOptOne.mop
